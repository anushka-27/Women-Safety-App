package com.example.womensafetyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ScrollView;

import com.google.android.material.textfield.TextInputLayout;
import com.hbb20.CountryCodePicker;

public class Signup3 extends AppCompatActivity {

    ScrollView scrollView;
    TextInputLayout phoneNo;
    CountryCodePicker countryCodePicker;
    TextInputLayout regfullname, regusername, regemail, regpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup3);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        scrollView = findViewById(R.id.signup_3rd_screen_scroll_view);
        countryCodePicker = findViewById(R.id.country_code_picker);
        phoneNo = findViewById(R.id.signup_phone_number);

        regfullname = findViewById(R.id.fullname);
        regusername = findViewById(R.id.username);
        regemail = findViewById(R.id.email);
        regpassword = findViewById(R.id.password);
    }

    private boolean validatePhoneNo() {
        String val = phoneNo.getEditText().toString();
        if (val.isEmpty()) {
            phoneNo.setError("Field cannot be empty");
            return false;
        } else {
           phoneNo.setError(null);
            return true;
        }
    }

    public void callVerifyOTPScreen(View view) {
        if (!validatePhoneNo()) {

            return;
        }

        String _fullName = getIntent().getStringExtra("fullName");
        String _email = getIntent().getStringExtra("email");
        String _username = getIntent().getStringExtra("username");
       String _password = getIntent().getStringExtra("password");
        String _date = getIntent().getStringExtra("date");


        String _getUserEnteredPhoneNumber = phoneNo.getEditText().getText().toString().trim();
        String _phoneNo = "+"+countryCodePicker.getFullNumber()+_getUserEnteredPhoneNumber;

        Intent intent = new Intent(getApplicationContext(), Verify_OTP.class);

        //Pass all fields to the next activity
       intent.putExtra("fullName",_fullName);
        intent.putExtra("email",_email);
       intent.putExtra("username",_username);
       intent.putExtra("password",_password);
        intent.putExtra("date",_date);
        intent.putExtra("phoneNo",_phoneNo);

        Pair[] pairs = new Pair[1];
        pairs[0] = new Pair<View, String>(scrollView, "transition_OTP_screen");
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(Signup3.this, pairs);
            startActivity(intent, options.toBundle());
        } else {
            startActivity(intent);
        }
    }


}
