package com.example.womensafetyapp;

public class MostViewedHelperClass {
    int imageView;
            String textView;

    public int getImageView() {
        return imageView;
    }

    public String getTextView() {
        return textView;
    }

    public MostViewedHelperClass(int imageView, String textView) {
        this.imageView = imageView;
        this.textView = textView;
    }
}
